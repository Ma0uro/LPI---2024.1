#ifndef SOMA_H
#define SOMA_H

int soma( int a, int b );
int menos( int a, int b );

#endif