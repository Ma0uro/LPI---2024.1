// gcc soma.c -c

#include<stdio.h>

#include"soma.h"

int soma( int va, int vb ) {

    return va + vb;
}

int menos( int va, int vb ) {

    return va - vb;
}