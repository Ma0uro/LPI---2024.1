#include <stdio.h>

#include"soma.h"


int main(int argc, char *argv[]) {
  
  int  va = 10, vb = 20, res = 0;

  res = soma(va, vb);
  
  printf("Soma a + b = %d\n", res);
  
  res = menos(va, vb);

  printf("meons + b = %d\n", res);
  
  return 0;
}